document.querySelector('#btnSave').addEventListener(
  'click',
  function() {
    let nodes = document.querySelectorAll('.mentions-texteditor__content');
    let list = [].slice.call(nodes);
    let innertext = list
      .map(function(e) {
        return e.innerText;
      })
      .join('\n');
    chrome.storage.sync.set({ message: innertext }, function() {
      alert('Message saved');
    });
  },
  false
);
